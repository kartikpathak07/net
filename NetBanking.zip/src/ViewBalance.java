

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.pb.dao.LoginDao;
import com.pb.dao.LoginDaoImpl;

/**
 * Servlet implementation class ViewBalance
 */
public class ViewBalance extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ViewBalance() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
			HttpSession session =request.getSession(false);
			String m_dbname = (String) request.getSession().getAttribute("a_username");
			System.out.println(m_dbname);
			LoginDao loginDao = new LoginDaoImpl();
			long bal=loginDao.viewBalance(m_dbname);
			PrintWriter out=response.getWriter();
			RequestDispatcher rd=request.getRequestDispatcher("viewbalance.jsp");
			rd.forward(request, response);
	}
	

}
