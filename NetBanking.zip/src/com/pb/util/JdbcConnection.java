package com.pb.util;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
public class JdbcConnection
{
	public static Connection getConnection()
	{
		Connection con=null;
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");

		}
		catch (ClassNotFoundException e) 
		{
			e.printStackTrace();
		}
		try 
		{
			con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","system");
			if(con!=null)
			{
				System.out.println("CONNECTED");
				return con;
			}
		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
		}
		return con;
		
		
	}
}


