package com.pb.dto;

public class Details {
private long bId;
	private String bName;
	private long bAccNo;
	private String uName;
	private String ifsc;
	private String status;
	private long chequeid;
	private String cAccNo;
	private String cStatus;
	private long ddId;
	private String ddaccNo;
	private String ddpayee;
	private long ddamt;
	private String ddstatus;
		
	@Override
	public String toString() {
		return "Details [bId=" + bId + ", bName=" + bName + ", bAccNo="
				+ bAccNo + ", uName=" + uName + ", ifsc=" + ifsc + ", status="
				+ status + ", chequeid=" + chequeid + ", cAccNo=" + cAccNo
				+ ", cStatus=" + cStatus + ", ddId=" + ddId + ", ddaccNo="
				+ ddaccNo + ", ddpayee=" + ddpayee + ", ddamt=" + ddamt
				+ ", ddstatus=" + ddstatus + "]";
	}
	public Details() {
		super();
	}
	public long getbId() {
		return bId;
	}
	public void setbId(long bId) {
		this.bId = bId;
	}
	public String getbName() {
		return bName;
	}
	public void setbName(String bName) {
		this.bName = bName;
	}
	public long getbAccNo() {
		return bAccNo;
	}
	public void setbAccNo(long bAccNo) {
		this.bAccNo = bAccNo;
	}
	public String getuName() {
		return uName;
	}
	public void setuName(String uName) {
		this.uName = uName;
	}
	public String getIfsc() {
		return ifsc;
	}
	public void setIfsc(String ifsc) {
		this.ifsc = ifsc;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public long getChequeid() {
		return chequeid;
	}
	public void setChequeid(long chequeid) {
		this.chequeid = chequeid;
	}
	public String getcAccNo() {
		return cAccNo;
	}
	public void setcAccNo(String cAccNo) {
		this.cAccNo = cAccNo;
	}
	public String getcStatus() {
		return cStatus;
	}
	public void setcStatus(String cStatus) {
		this.cStatus = cStatus;
	}
	public long getDdId() {
		return ddId;
	}
	public void setDdId(long ddId) {
		this.ddId = ddId;
	}
	public String getDdaccNo() {
		return ddaccNo;
	}
	public void setDdaccNo(String ddaccNo) {
		this.ddaccNo = ddaccNo;
	}
	public String getDdpayee() {
		return ddpayee;
	}
	public void setDdpayee(String ddpayee) {
		this.ddpayee = ddpayee;
	}
	public long getDdamt() {
		return ddamt;
	}
	public void setDdamt(long ddamt) {
		this.ddamt = ddamt;
	}
	public String getDdstatus() {
		return ddstatus;
	}
	public void setDdstatus(String ddstatus) {
		this.ddstatus = ddstatus;
	}
	public Details(long bId, String bName, long bAccNo, String uName,
			String ifsc, String status, long chequeid, String cAccNo,
			String cStatus, long ddId, String ddaccNo, String ddpayee,
			long ddamt, String ddstatus) {
		super();
		this.bId = bId;
		this.bName = bName;
		this.bAccNo = bAccNo;
		this.uName = uName;
		this.ifsc = ifsc;
		this.status = status;
		this.chequeid = chequeid;
		this.cAccNo = cAccNo;
		this.cStatus = cStatus;
		this.ddId = ddId;
		this.ddaccNo = ddaccNo;
		this.ddpayee = ddpayee;
		this.ddamt = ddamt;
		this.ddstatus = ddstatus;
	}
	
}
