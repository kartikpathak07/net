package com.pb.dao;

import com.pb.dto.UserDetails;

public interface UserDetailsDao 
{
	boolean insertrec(UserDetails user);
}
