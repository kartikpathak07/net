package com.pb.dao;

import java.sql.SQLException;
import java.util.List;

public interface BeneficiaryDao 
{
public int addBeneficiary(long account_no, String username,
int ifsc,String benname);
public List viewBeneficiary(String username) throws SQLException;
}
