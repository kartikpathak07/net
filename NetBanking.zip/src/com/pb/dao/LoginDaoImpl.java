package com.pb.dao;




import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import com.pb.dto.Information;
import com.pb.dto.Login;
import com.pb.util.JdbcConnection;

public class LoginDaoImpl implements LoginDao
{

	public String validate(String username,String password) 

	{
		Connection conn=null;
		conn=JdbcConnection.getConnection();
		PreparedStatement pst=null;
		String role=null;
		ResultSet rs=null;

		try {
			pst=conn.prepareStatement("select role from banklogin where username = ? and password = ?");
			pst.setString(1, username);
			pst.setString(2, password);

			rs  = pst.executeQuery();

			if(rs.next())
			{
				role=rs.getString(1);
				System.out.println(role);
				return role;
			}
			else
			{
				role="notavailable";
				return role;
			}

		} 
		catch (SQLException e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
			try 
			{
				rs.close();
				pst.close();
				conn.close();
			} 
			catch (SQLException e) 
			{
				e.printStackTrace();
			}
		}
		return role;
	}
	//METHOD TO UPDATE ADMIN PASSWORD
	public String updatePassword(String m_dbname, String oldpassword,
			String newpassword, String verifypassword)
	{
		String stat=null;
		Connection conn=null;
		conn=JdbcConnection.getConnection();
		PreparedStatement pst=null;
		System.out.println("hello IN update password page");

		String query= "select * from banklogin where username=?";

		try 
		{


			pst=conn.prepareStatement(query);
			pst.setString(1,m_dbname);

			ResultSet rec= pst.executeQuery();

			while(rec.next())
			{

				String tempUsername = rec.getString(1);
				String dbpassword=rec.getString(2);
				//System.out.println(dbpassword);
				if(oldpassword.equals(dbpassword))
				{
					if(newpassword.equals(verifypassword))
					{
						//System.out.println("IF Bolck execites");
						String query1=" update banklogin set password=? where username=?";
						PreparedStatement pst1=conn.prepareStatement(query1);

						pst1.setString(1, newpassword);
						pst1.setString(2, tempUsername);

						pst1.executeUpdate();
						System.out.println("Password changed");
						stat="pass";
					}

					else
					{
						stat="fail";
					}

				}
				else
				{
					stat="fail";
				}
			}
		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
		}
		finally
		{
			try 
			{
				conn.close();
			} 
			catch (SQLException e) 
			{
				e.printStackTrace();
			}
		}
		return stat;

	}

	public boolean insertrec(Login login) 
	{
		Connection conn=null;
		conn=JdbcConnection.getConnection();
		PreparedStatement pst=null;
		String query="INSERT INTO BANKLOGIN VALUES(?,?,?)";
		try 
		{
			pst=conn.prepareStatement(query);
			pst.setString(1,login.getUsername());
			pst.setString(2,login.getPassword());
			pst.setString(3,"user");
			int rec=pst.executeUpdate();
			if(rec==1)
			{
				return true;
			}
		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
		}
		finally
		{
			try 
			{
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}
		return false;
	}


	{

	}


	public long viewBalance(String username) 
	{
		long balance=0;
		Connection conn=null;
		conn=JdbcConnection.getConnection();
		PreparedStatement pst=null;
		String query="SELECT * FROM BANKUSER WHERE USERNAME=?";
		try {
			System.out.println(username);

			pst=conn.prepareStatement(query);
			pst.setString(1,username);

			ResultSet rs= pst.executeQuery();
			if(rs.next()==true)
			{	
				System.out.println("IF WORKING");
				balance=rs.getLong(4);
				return balance;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return 0;




	}


	public List<Information> updateProfile(String username) {
		// TODO Auto-generated method stub


		Connection conn=null;
		conn=JdbcConnection.getConnection();
		PreparedStatement pst=null;
		System.out.println("---Updating Profile");
		ArrayList<Information> contents = new ArrayList<Information>();
		
		String query= "select * from Bankuser where username=?";
		try {

			pst=conn.prepareStatement(query);
			pst.setString(1, username);
			ResultSet rs=pst.executeQuery();
			System.out.println(username);
			

			if(rs.next()==true)
			{

				String custname=rs.getString(3);
				String address=rs.getString(6);
				long contactno=rs.getLong(7);
				String emailid=rs.getString(8);

				Information inf = new Information(custname,address, contactno,emailid);
				contents.add(inf);
			}
			else
			{
				System.out.println("data not found");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
			try 
			{
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}

		return contents;


	}
	public int updateProfileData(String dbname,String address,long contactno,String email)
	{
		int i=0;
		Connection conn=null;
		conn=JdbcConnection.getConnection();
		PreparedStatement pst=null;


		String query= "UPDATE BankUser SET address=?,phone_no=?,email_id=? where username=?";

		try {
			pst=conn.prepareStatement(query);

			pst.setString(1,address);
			pst.setLong(2, contactno);
			pst.setString(3,email);
			pst.setString(4, dbname);
			System.out.println("Update Working");
			int rs=pst.executeUpdate();
			if(rs==1)
			{
				i=1;
			}
			else 
			{

				i=0;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally
		{
			try 
			{
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}

		return i;

	}
	public int chequeRequest(long account_no) 
	{
		
		DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd");
		Date date = new Date();
		java.sql.Date datesql=new java.sql.Date(date.getYear(), date.getMonth(), date.getDay());
		
		int i=1;
		int rand=(int) (Math.random()*1000);
		System.out.println(rand);
		int cheque_no=rand;
		Connection conn=null;
		conn=JdbcConnection.getConnection();
		String query= "insert into ChequeBook values(?,?,to_date(?, 'yyyy-mm-dd'),?)";
		try {
			PreparedStatement pst= conn.prepareStatement(query);
			pst.setInt(1,cheque_no);
			pst.setString(2,account_no+"");
			pst.setDate(3,datesql);
			pst.setString(4,"REQUESTED");
			int updateCount=pst.executeUpdate();
			if(updateCount>0)
			{
				i=0;
			}
			else{
				i=1;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
			try {
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return i;
	}
	public int ddRequest(String account_no, String payee,long amount) 
	{
		DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd");
		Date date = new Date();
		java.sql.Date datesql=new java.sql.Date(date.getYear(), date.getMonth(), date.getDay());
		
		int i=1;
		int rand=(int) (Math.random()*1000);
		String ddno=""+rand;
		Connection conn=null;
		conn=JdbcConnection.getConnection();
		String query= "INSERT into demanddraft values(?,?,?,to_date(?, 'yyyy-mm-dd'),?,?)";
		try {
			PreparedStatement pst= conn.prepareStatement(query);
			pst.setString(1,ddno);
			pst.setString(2,account_no);
			pst.setString(3, payee);
			pst.setDate(4, datesql);
			pst.setLong(5, amount);
			pst.setString(6, "Requested");

			int updateCount=pst.executeUpdate();
			System.out.println("--------Pochala");
			if(updateCount>0)
				{
				i=0;
				System.out.println("------------jhala");
				}
			else
				{
				i=1;
				System.out.println("------------nahi  jhala");
				}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
			try {
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return i;
	}

	public boolean differentiate(String username) 
	{
		Connection conn=null;
		conn=JdbcConnection.getConnection();
		PreparedStatement pst=null;
		ResultSet rs=null;
		System.out.println("Diferentiating");
		String query= "SELECT ROLE FROM BANKLOGIN WHERE USERNAME=?";
		try
		{
			pst=conn.prepareStatement(query);
			pst.setString(1, username);
			rs=pst.executeQuery();
			rs.next();
			if(rs.getString(1).equalsIgnoreCase("admin"))
				return true;
			else
				return false;
		}
		catch (SQLException e)
		{
			e.printStackTrace();
		}
		finally
		{
			try {

				rs.close();
				pst.clearParameters();
				pst.close();
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return false;

	}


}




