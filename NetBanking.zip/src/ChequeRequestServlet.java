

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.pb.dao.BeneficiaryDaoImpl;
import com.pb.dao.LoginDaoImpl;

/**
 * Servlet implementation class ChequeRequestServlet
 */
public class ChequeRequestServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ChequeRequestServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		PrintWriter out=response.getWriter();
		HttpSession session =request.getSession(false);
		String m_dbname = (String) request.getSession().getAttribute("a_username");
		
		String maccountno=request.getParameter("accountno");
		long m_accountno=Long.parseLong(maccountno);
		System.out.println(m_accountno);
		LoginDaoImpl ldao=new LoginDaoImpl();
		int check=ldao.chequeRequest(m_accountno);
		if(check==0)
		{
			out.print("chequebook request SUCCESSFUL");
			RequestDispatcher rd=request.getRequestDispatcher("Success.jsp");
			rd.forward(request, response);
		}
		else
		{
			out.print("wrong account number");
			RequestDispatcher rd=request.getRequestDispatcher("Failure.jsp");
			rd.forward(request, response);
		}
	}

}
