

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.pb.dao.BeneficiaryDaoImpl;
import com.pb.dto.Details;

/**
 * Servlet implementation class ActivateBeneficiaryServlet
 */
public class ActivateBeneficiaryServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ActivateBeneficiaryServlet() {
        super();
        // TODO Auto-generated constructor stub
    }
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("In activate beneficiary servlet");
		HttpSession session = request.getSession();
		String uname = (String) session.getAttribute("a_username");
		
		BeneficiaryDaoImpl bdao = new BeneficiaryDaoImpl();
		PrintWriter out = response.getWriter();
		response.setContentType("text/html");
		BeneficiaryDaoImpl bdao1 = new BeneficiaryDaoImpl();
		Details dt= new Details();
		String id=request.getParameter("value");
		
		//System.out.println(id);
		
		int check=bdao1.approveBeneficiary(id);
		if(check==1)
		{
			System.out.println("APPROVED");
			RequestDispatcher rd=request.getRequestDispatcher("AdminPage.jsp");
			rd.forward(request, response);
		}
		else
		{
			System.out.println("NOT UPDATED");
		}
		
	
	}

}
